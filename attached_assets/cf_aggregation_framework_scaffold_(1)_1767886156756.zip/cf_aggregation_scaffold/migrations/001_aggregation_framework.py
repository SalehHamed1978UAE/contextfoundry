"""
Aggregation Framework Database Migration

Creates the tables required for v1.3 spec:
- agg_definitions: Semantic contract registry (§4.1)
- aggregation_metadata: Result cache (§6.2)
- doc_entity_mentions: Document mention index (§6.3)

Run with: alembic upgrade head
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# Revision identifiers
revision = "001_aggregation_framework"
down_revision = None  # Set to previous migration
branch_labels = None
depends_on = None


def upgrade():
    # ==========================================================================
    # 1. agg_definitions - Semantic contract registry (§4.1)
    # ==========================================================================
    op.create_table(
        "agg_definitions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, 
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("concept_key", sa.Text(), nullable=False),
        sa.Column("synonyms", postgresql.ARRAY(sa.Text()), nullable=False, 
                  server_default="{}"),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("status", sa.Text(), nullable=False, server_default="active"),
        sa.Column("candidates", postgresql.JSONB(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.UniqueConstraint("tenant_id", "concept_key", "version",
                           name="uq_agg_defs_tenant_concept_version"),
    )
    
    op.create_index(
        "idx_agg_defs_tenant_concept",
        "agg_definitions",
        ["tenant_id", "concept_key"],
    )
    
    # RLS policy
    op.execute("""
        ALTER TABLE agg_definitions ENABLE ROW LEVEL SECURITY;
        
        CREATE POLICY agg_defs_tenant_isolation ON agg_definitions
            USING (tenant_id = current_setting('app.current_tenant')::uuid);
    """)
    
    # ==========================================================================
    # 2. aggregation_metadata - Result cache (§6.2)
    # ==========================================================================
    op.create_table(
        "aggregation_metadata",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("plan_hash", sa.Text(), nullable=False),
        sa.Column("plan_version", sa.Integer(), nullable=False),
        sa.Column("result_kind", sa.Text(), nullable=False),  # EXACT|LOWER_BOUND|RANGE
        sa.Column("value", sa.Numeric(), nullable=True),
        sa.Column("lower_bound", sa.Numeric(), nullable=True),
        sa.Column("upper_bound", sa.Numeric(), nullable=True),
        sa.Column("confidence", sa.Numeric(), nullable=False),
        sa.Column("evidence_envelope", postgresql.JSONB(), nullable=False),
        sa.Column("computed_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("tenant_id", "plan_hash", "plan_version",
                           name="uq_aggmeta_tenant_plan"),
    )
    
    op.create_index(
        "idx_aggmeta_tenant_expires",
        "aggregation_metadata",
        ["tenant_id", "expires_at"],
    )
    
    op.execute("""
        ALTER TABLE aggregation_metadata ENABLE ROW LEVEL SECURITY;
        
        CREATE POLICY aggmeta_tenant_isolation ON aggregation_metadata
            USING (tenant_id = current_setting('app.current_tenant')::uuid);
    """)
    
    # ==========================================================================
    # 3. doc_entity_mentions - Document mention index (§6.3)
    # ==========================================================================
    op.create_table(
        "doc_entity_mentions",
        sa.Column("tenant_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("doc_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("entity_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("mention_count", sa.Integer(), nullable=True),
        sa.Column("first_seen_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("tenant_id", "doc_id", "entity_id"),
    )
    
    op.create_index(
        "idx_mentions_tenant_entity",
        "doc_entity_mentions",
        ["tenant_id", "entity_id"],
    )
    
    op.execute("""
        ALTER TABLE doc_entity_mentions ENABLE ROW LEVEL SECURITY;
        
        CREATE POLICY mentions_tenant_isolation ON doc_entity_mentions
            USING (tenant_id = current_setting('app.current_tenant')::uuid);
    """)
    
    # ==========================================================================
    # 4. Additional indices for aggregation queries (§6.1)
    # ==========================================================================
    
    # These assume entities and relationships tables exist
    # Wrap in try/except for safety
    op.execute("""
        -- Entities index for aggregation
        CREATE INDEX IF NOT EXISTS idx_entities_tenant_type
            ON entities (tenant_id, entity_type);
        
        -- Relationships indices for aggregation (both directions)
        CREATE INDEX IF NOT EXISTS idx_rel_tenant_src_type
            ON relationships (tenant_id, source_entity_id, relationship_type);
        
        CREATE INDEX IF NOT EXISTS idx_rel_tenant_tgt_type
            ON relationships (tenant_id, target_entity_id, relationship_type);
        
        -- DTL decisions index for aggregation
        CREATE INDEX IF NOT EXISTS idx_decisions_tenant_type_time
            ON dtl_decisions (tenant_id, decision_type, created_at);
    """)


def downgrade():
    # Drop in reverse order
    op.execute("""
        DROP POLICY IF EXISTS mentions_tenant_isolation ON doc_entity_mentions;
        DROP POLICY IF EXISTS aggmeta_tenant_isolation ON aggregation_metadata;
        DROP POLICY IF EXISTS agg_defs_tenant_isolation ON agg_definitions;
    """)
    
    op.drop_table("doc_entity_mentions")
    op.drop_table("aggregation_metadata")
    op.drop_table("agg_definitions")
    
    # Don't drop the additional indices as they may be used elsewhere
