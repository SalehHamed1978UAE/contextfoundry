# Context Foundry Aggregation Framework - Integration Guide

## Overview

This scaffold implements the v1.3 Aggregation Framework spec. It integrates with Context Foundry without rewrites by:

1. **Adding a dedicated `AggregationService`** called from `ContextFoundry.query()` after intent classification
2. **Reusing existing SQLAlchemy session** for automatic RLS enforcement
3. **Extending `ContextBundle`** to carry aggregation metadata
4. **Using feature flags** for safe rollout

## Directory Structure

```
aggregation/
├── __init__.py          # Package exports
├── models.py            # Data structures (AggIntent, CAT, ResultKind, etc.)
├── service.py           # Main orchestrator (AggregationService)
├── intent.py            # DSPy-based intent classification + semantic resolution
├── registry.py          # CRUD for agg_definitions table
├── planner.py           # CAT → ExecutionPlan mapping
├── executor.py          # SQL/graph execution with RLS
├── crc.py               # Lincoln-Petersen Capture-Recapture estimation
├── sufficiency.py       # Numeric sufficiency gate
└── formatter.py         # Answer composition

migrations/
└── 001_aggregation_framework.py  # Database migration for new tables
```

## Integration Steps

### 1. Run Database Migration

```bash
# Add migration to your alembic migrations folder
cp migrations/001_aggregation_framework.py \
   platform_foundation/migrations/versions/

# Run migration
alembic upgrade head
```

This creates:
- `agg_definitions` - Semantic contract registry
- `aggregation_metadata` - Result cache
- `doc_entity_mentions` - Document mention index (for EXACT doc counts)

### 2. Add Aggregation Module

Copy the `aggregation/` folder to `src/context_foundry/aggregation/`.

### 3. Hook into ContextFoundry.query()

In `src/context_foundry/agents/retrieval.py` around line 100-220, add:

```python
from context_foundry.aggregation import try_aggregation_query

class ContextFoundry:
    def query(self, question: str, user_ctx: dict = None, **kwargs):
        # ... existing intent classification ...
        
        # NEW: Try aggregation before tri-memory pipeline
        if self.feature_flags.get("aggregation.enabled", False):
            agg_result = try_aggregation_query(
                session=self.session,
                tenant_id=self.tenant_id,
                question=question,
                user_ctx=user_ctx,
                anchor_entities=resolved_entities,  # From existing resolution
                feature_flags=self.feature_flags,
            )
            
            if agg_result is not None:
                # Aggregation handled it
                return self._format_aggregation_response(agg_result)
        
        # ... continue with existing tri-memory pipeline ...
```

### 4. Extend ContextBundle

In `src/context_foundry/models/context_bundle.py`:

```python
from typing import Optional
from context_foundry.aggregation.models import CAT, EvidenceEnvelope

@dataclass
class ContextBundle:
    # ... existing fields ...
    
    # NEW: Aggregation fields
    aggregation_target: Optional[CAT] = None
    aggregation_plan: Optional[dict] = None
    evidence_envelope: Optional[EvidenceEnvelope] = None
```

### 5. Wire into ValidationAgent

In your ValidationAgent, add numeric sufficiency check:

```python
from context_foundry.aggregation.sufficiency import SufficiencyGate
from context_foundry.aggregation.models import ResultKind

class ValidationAgent:
    def validate_aggregation(self, result):
        if result.result_kind == ResultKind.INSUFFICIENT:
            # Trigger fallback to listing
            return self.fallback_to_listing(result)
        return result
```

### 6. Configure Feature Flags

```python
FEATURE_FLAGS = {
    "aggregation.enabled": False,  # Master switch
    "aggregation.count.enabled": False,
    "aggregation.avg.enabled": False,
    "aggregation.graph.enabled": False,
    "aggregation.crc_estimation.enabled": False,
    "aggregation.dspy_resolution.enabled": False,
    "aggregation.tenant_allowlist": [],
}
```

## Usage

### Basic Usage

```python
from context_foundry.aggregation import AggregationService

service = AggregationService(session, tenant_id, feature_flags)
result = service.handle_query("How many jobs has Saleh had?")

if result.is_success:
    print(result.display_text)  # "4 jobs"
else:
    print(result.assumptions)   # Why it failed
```

### Registering Semantic Contracts

```python
from context_foundry.aggregation import AggDefinitionRegistry

registry = AggDefinitionRegistry(session, tenant_id)
registry.register_definition(
    concept_key="job",
    synonyms=["role", "position", "employment"],
    candidates=[
        {
            "name": "Distinct employment records",
            "intent_kinds": ["COUNT_DISTINCT", "COUNT"],
            "target": {
                "source": "KG_RELATIONSHIP",
                "relationship_type": "WORKED_AT",
                "anchor_entity_type": "Person",
            },
            "aggregation": {
                "op": "COUNT_DISTINCT",
                "grouping_key": ["organization_id", "start_date"],
            },
            "closure_policy": "AUTHORITATIVE",
            "confidence_baseline": 0.85,
        }
    ],
)
```

## Testing

Add tests under `tests/aggregation/`:

```python
# test_intent.py
def test_intent_classification():
    classifier = IntentClassifier()
    intent = classifier.classify("How many jobs has Saleh had?")
    assert intent.kind == IntentKind.COUNT_DISTINCT
    assert "job" in intent.subject_phrase

# test_crc.py
def test_lincoln_petersen():
    from context_foundry.aggregation.crc import estimate_population
    bounds = estimate_population(n_a=12, n_b=10, overlap=8)
    assert bounds.expected == 15  # (12*10)/8
    assert bounds.lower <= 15 <= bounds.upper

# test_sufficiency.py
def test_exact_result_for_authoritative():
    gate = SufficiencyGate()
    # ... test that AUTHORITATIVE + high confidence → EXACT
```

## Rollout Plan

### Week 1: Shadow Mode
- Enable logging only (no user-visible results)
- Monitor intent classification accuracy

### Week 2: Canary
- Enable for internal tenant
- COUNT/COUNT_DISTINCT only

### Weeks 3-6: Ramp
- Add TIME WINDOW, AVG, GROUP BY
- Expand to more tenants
- Enable CRC estimation

### Weeks 7-8: GA
- 100% tenants
- Full feature set
- Caching enabled

## Key Safety Rules

1. **NO COUNTING FROM RETRIEVAL**: Retrieval results are never complete sets
2. **RLS ALWAYS**: All queries run through SQLAlchemy session with tenant context
3. **DETERMINISTIC ONLY**: No LLM-generated SQL at runtime
4. **EXPLICIT BOUNDS**: LOWER_BOUND/RANGE when data is incomplete

## Troubleshooting

### "INSUFFICIENT" results
- Check if `agg_definitions` has a matching concept
- Verify closure_policy is appropriate
- Check confidence components in result

### Cross-tenant leakage
- Verify `app.current_tenant` is set before queries
- Run tenant isolation tests

### Missing DSPy
- Falls back to rule-based classification automatically
- Install with: `pip install dspy-ai`
