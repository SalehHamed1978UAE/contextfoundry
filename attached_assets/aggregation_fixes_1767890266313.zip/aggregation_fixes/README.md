# Aggregation Framework Fixes

Three gaps that make some features dead code until addressed.

## Files in This Package

```
aggregation_fixes/
├── migrations/
│   └── 002_entity_dedup_hints.sql    # New table + helper function
├── aggregation/
│   ├── mentions_indexer.py           # Populates doc_entity_mentions
│   ├── seed_definitions.py           # Seeds agg_definitions with domain concepts
│   └── hooks.py                      # Integration hooks for existing pipelines
└── README.md                         # This file
```

---

## Fix 1: Entity Dedup Hints Table

**Problem:** FUZZY_HINTS dedup policy references hints that don't exist.

**Solution:** Run the migration.

```bash
# Copy to migrations folder
cp migrations/002_entity_dedup_hints.sql src/context_foundry/migrations/

# Run migration (adapt to your migration runner)
psql $DATABASE_URL < src/context_foundry/migrations/002_entity_dedup_hints.sql
```

This creates:
- `entity_dedup_hints` table with RLS
- `v_entity_dedup_hints` helper view
- `get_ambiguous_merge_rate()` function for sufficiency gate

---

## Fix 2: Document Mentions Population

**Problem:** `doc_entity_mentions` table exists but is empty. "How many docs mention X?" returns 0.

**Solution:** Wire indexer into document ingestion pipeline.

```python
# Copy to aggregation module
cp aggregation/mentions_indexer.py src/context_foundry/aggregation/
cp aggregation/hooks.py src/context_foundry/aggregation/

# In your document processing pipeline, add:
from context_foundry.aggregation.hooks import on_document_processed

def process_document(doc):
    chunks = chunk_document(doc)
    entities = extract_entities(chunks)
    
    # ... existing code to save chunks/entities ...
    
    # NEW: Index for aggregation
    on_document_processed(session, tenant_id, doc.id, entities)
```

**Backfill existing documents:**

```python
from context_foundry.aggregation.mentions_indexer import DocEntityMentionsIndexer

indexer = DocEntityMentionsIndexer(session, tenant_id)

# Option A: If you have chunk_entity_links table
indexer.backfill_from_entity_links()

# Option B: Custom extractor
def extract_entities_from_chunk(content, metadata):
    # Your entity extraction logic
    return [entity_id1, entity_id2, ...]

indexer.backfill_from_chunks(extract_entities_from_chunk)
```

---

## Fix 3: Seed Aggregation Definitions

**Problem:** `agg_definitions` table exists but is empty. System doesn't know what "jobs", "incidents", etc. mean.

**Solution:** Seed domain definitions.

```python
# Copy to aggregation module
cp aggregation/seed_definitions.py src/context_foundry/aggregation/

# Run seed
from context_foundry.aggregation.seed_definitions import seed_all_definitions

with session:
    session.execute(text(f"SET app.current_tenant = '{tenant_id}'"))
    stats = seed_all_definitions(session, tenant_id)
    session.commit()
    print(stats)  # {'seeded': 10, 'failed': 0}
```

**Or via CLI:**

```bash
python -m context_foundry.aggregation.seed_definitions \
    --tenant-id YOUR_TENANT_UUID \
    --db-url postgresql://...
```

---

## Included Domain Concepts

The seed data includes definitions for:

| Concept | Synonyms | Example Query |
|---------|----------|---------------|
| job | role, position, employment | "How many jobs has Saleh had?" |
| incident | issue, outage, ticket | "How many incidents last quarter?" |
| exception | waiver, exemption | "How many exceptions granted?" |
| approval | authorization, sign-off | "How many approvals pending?" |
| vendor | supplier, contractor | "How many vendors in each category?" |
| system | service, application | "How many systems depend on X?" |
| document | doc, report, file | "How many docs mention Project Phoenix?" |
| portfolio_company | portco, subsidiary | "How many portfolio companies?" |
| project | initiative, program | "How many active projects?" |
| person | contributor, employee | "How many contributors to X?" |

---

## Wire Into Existing Pipelines

### Document Ingestion

```python
from context_foundry.aggregation.hooks import on_document_processed, on_document_deleted

# After processing
on_document_processed(session, tenant_id, doc_id, extracted_entities)

# On delete
on_document_deleted(session, tenant_id, doc_id)
```

### Entity Resolution

```python
from context_foundry.aggregation.hooks import on_entities_merged, record_dedup_hint

# When merging entities
on_entities_merged(session, tenant_id, source_id, target_id, similarity_score)

# When recording uncertain pairs
record_dedup_hint(session, tenant_id, e1_id, e2_id, 0.7, 'uncertain', 'auto')
```

### Sufficiency Gate Enhancement

Update `sufficiency.py` to use real dedup penalty:

```python
from context_foundry.aggregation.hooks import get_dedup_penalty

def _estimate_er_penalty(self, raw_result):
    # Replace placeholder with real calculation
    return get_dedup_penalty(
        self.session, 
        self.tenant_id, 
        raw_result.entity_ids
    )
```

---

## Verification

After applying fixes:

```python
# Check definitions loaded
from context_foundry.aggregation.seed_definitions import list_definitions
defs = list_definitions(session, tenant_id)
print(f"Definitions: {len(defs)}")  # Should be 10

# Check mentions index
from context_foundry.aggregation.mentions_indexer import DocEntityMentionsIndexer
indexer = DocEntityMentionsIndexer(session, tenant_id)
stats = indexer.get_stats()
print(f"Indexed: {stats['doc_count']} docs, {stats['entity_count']} entities")

# Test a query
from context_foundry.aggregation import AggregationService
service = AggregationService(session, tenant_id)
result = service.handle_query("How many jobs has Saleh had?")
print(f"{result.result_kind}: {result.display_text}")
```
