# Aggregation Framework - Complete the Gaps

## Context
The Aggregation Framework is integrated but 3 features are dead code without these fixes.

## Files Provided
- `aggregation_fixes.zip` - Contains migrations, indexer, seed data, and hooks

## Tasks

### Task 1: Run entity_dedup_hints Migration

```bash
# Copy migration
cp aggregation_fixes/migrations/002_entity_dedup_hints.sql src/context_foundry/migrations/

# Run it
psql $DATABASE_URL < src/context_foundry/migrations/002_entity_dedup_hints.sql
```

Creates:
- `entity_dedup_hints` table (backs FUZZY_HINTS dedup policy)
- `get_ambiguous_merge_rate()` function

### Task 2: Add Mentions Indexer

Copy files:
```bash
cp aggregation_fixes/aggregation/mentions_indexer.py src/context_foundry/aggregation/
cp aggregation_fixes/aggregation/hooks.py src/context_foundry/aggregation/
```

Wire into document ingestion. Find where documents are processed and add:
```python
from context_foundry.aggregation.hooks import on_document_processed

# After entity extraction:
on_document_processed(session, tenant_id, doc_id, extracted_entities)
```

### Task 3: Seed Aggregation Definitions

Copy file:
```bash
cp aggregation_fixes/aggregation/seed_definitions.py src/context_foundry/aggregation/
```

Create a startup hook or management command:
```python
from context_foundry.aggregation.seed_definitions import seed_all_definitions

def seed_aggregation_definitions(session, tenant_id):
    return seed_all_definitions(session, tenant_id)
```

### Task 4: Update Sufficiency Gate

In `src/context_foundry/aggregation/sufficiency.py`, update `_estimate_er_penalty`:

```python
def _estimate_er_penalty(self, raw_result: RawAggregationResult) -> float:
    """Estimate penalty from entity resolution uncertainty."""
    from .hooks import get_dedup_penalty
    
    # Get real penalty from dedup hints
    if hasattr(raw_result, 'entity_ids') and raw_result.entity_ids:
        return get_dedup_penalty(
            self.session,
            self.tenant_id,
            raw_result.entity_ids
        )
    return 0.0
```

### Task 5: Add Tests

```python
def test_dedup_hints_created():
    """Verify entity_dedup_hints table exists."""
    result = session.execute(text("SELECT 1 FROM entity_dedup_hints LIMIT 1"))
    # Should not throw

def test_definitions_seeded():
    """Verify agg_definitions populated."""
    from context_foundry.aggregation.seed_definitions import list_definitions
    defs = list_definitions(session, tenant_id)
    assert len(defs) >= 10  # We seed 10 concepts

def test_mentions_indexer():
    """Verify mentions indexer works."""
    from context_foundry.aggregation.mentions_indexer import DocEntityMentionsIndexer
    indexer = DocEntityMentionsIndexer(session, tenant_id)
    
    # Index a test document
    from context_foundry.aggregation.mentions_indexer import EntityMention
    mentions = [EntityMention(entity_id=test_entity_id, mention_count=3)]
    count = indexer.index_document(test_doc_id, mentions)
    assert count == 1
    
    # Verify stats
    stats = indexer.get_stats()
    assert stats['doc_count'] >= 1
```

## Verification

After all tasks complete:

```python
# 1. Definitions loaded
from context_foundry.aggregation.seed_definitions import list_definitions
assert len(list_definitions(session, tenant_id)) >= 10

# 2. Dedup hints table works
session.execute(text("""
    INSERT INTO entity_dedup_hints 
        (tenant_id, entity1_id, entity2_id, similarity_score, decision)
    VALUES 
        (:tid, :e1, :e2, 0.8, 'merge')
"""), {"tid": str(tenant_id), "e1": str(uuid4()), "e2": str(uuid4())})

# 3. Mentions indexer works
from context_foundry.aggregation.mentions_indexer import DocEntityMentionsIndexer
indexer = DocEntityMentionsIndexer(session, tenant_id)
stats = indexer.get_stats()
print(f"Mentions indexed: {stats}")
```

## Done When
- [ ] `entity_dedup_hints` table exists with RLS
- [ ] `mentions_indexer.py` in aggregation module
- [ ] `hooks.py` in aggregation module  
- [ ] `seed_definitions.py` in aggregation module
- [ ] Document ingestion calls `on_document_processed()`
- [ ] Tests pass
- [ ] `seed_all_definitions()` populates 10 concepts
