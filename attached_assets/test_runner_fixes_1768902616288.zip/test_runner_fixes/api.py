"""
Test Runner API Blueprint

Provides REST API endpoints for the Test Runner Dashboard:
- Question Sets management (upload, list, get, delete)
- Test Control (start, status, stop, force-clear)
- History & Results
- Corpus folders listing
"""

import json
import os
import subprocess
import signal
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

from flask import Blueprint, request, jsonify, session
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from functools import wraps

from .persistence import (
    create_test_run,
    update_test_run_stage,
    complete_test_run,
    get_running_test,
    reset_test_run_for_resume,
    recover_file_test_to_db,
    cleanup_orphaned_running_tests,
    force_clear_all_running_tests,
    HEARTBEAT_TIMEOUT_SECONDS
)

test_runner_api = Blueprint('test_runner_api', __name__, url_prefix='/api/test-runner')


# =============================================================================
# STARTUP CLEANUP
# =============================================================================
# When this module loads (server startup), clean up any orphaned "running" tests.
# Since the server just started, no test subprocess could still be running.
# =============================================================================

def _run_startup_cleanup():
    """Run cleanup on module load."""
    try:
        count = cleanup_orphaned_running_tests()
        if count > 0:
            print(f"[Test Runner API] Startup cleanup: marked {count} orphaned test(s) as interrupted")
    except Exception as e:
        print(f"[Test Runner API] Startup cleanup failed (DB may not be ready): {e}")

# Run cleanup when module loads
_run_startup_cleanup()


def require_auth(f):
    """Decorator to require authentication for API endpoints."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('user_id'):
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function

STATUS_FILE_PATH = Path('data/test-runner/status.json')
CORPUS_FOLDERS_PATH = Path('test documents')


def get_db_session():
    """Get database session."""
    database_url = os.environ.get('DATABASE_URL')
    if not database_url:
        raise RuntimeError("DATABASE_URL not configured")
    engine = create_engine(database_url)
    Session = sessionmaker(bind=engine)
    return Session()


def read_status_file():
    """Read the current test status from status file."""
    if not STATUS_FILE_PATH.exists():
        return None
    try:
        with open(STATUS_FILE_PATH) as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return None


def write_status_file(status: dict):
    """Write status to status file."""
    STATUS_FILE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(STATUS_FILE_PATH, 'w') as f:
        json.dump(status, f, indent=2, default=str)


def clear_status_file():
    """Clear the status file."""
    if STATUS_FILE_PATH.exists():
        STATUS_FILE_PATH.unlink()


import re

def parse_markdown_questions(content: str) -> list:
    """Parse questions from markdown format. Supports multiple formats:

    Format 1 (Q/A numbered):
        **Q1:** What is the question?
        **A1:** The answer
        **Source:** optional_source.md

    Format 2 (Question/Answer labeled):
        ### Q1
        **Question:** What is the question?
        **Answer:** The answer
    """
    questions = []

    # Format 1: **Q1:** ... **A1:** ...
    qa_pattern = re.compile(
        r'\*\*Q(\d+):\*\*\s*(.+?)\s*\n'
        r'\*\*A\1:\*\*\s*(.+?)\s*\n'
        r'(?:\*\*Source:\*\*\s*(.+?)\s*\n)?'
        r'(?:\*\*Type:\*\*\s*(.+?)\s*(?:\n|$))?',
        re.MULTILINE
    )

    for match in qa_pattern.finditer(content):
        q_num, question, answer, source, q_type = match.groups()
        q_obj = {
            'question': question.strip(),
            'expected_answer': answer.strip()
        }
        if source:
            q_obj['source'] = source.strip()
        if q_type:
            q_obj['type'] = q_type.strip()
        questions.append(q_obj)

    # If format 1 found questions, return them
    if questions:
        return questions

    # Format 2: ### Q1 \n **Question:** ... **Answer:** ...
    question_pattern = re.compile(
        r'###\s*Q(\d+)\s*\n'
        r'\*\*Question:\*\*\s*(.+?)\s*\n'
        r'\*\*Answer:\*\*\s*(.+?)\s*\n'
        r'(?:\*\*Source:\*\*\s*(.+?)\s*\n)?'
        r'(?:\*\*Type:\*\*\s*(.+?)\s*\n)?'
        r'(?:\*\*Difficulty:\*\*\s*(.+?)\s*(?:\n|$))?',
        re.MULTILINE | re.DOTALL
    )

    for match in question_pattern.finditer(content):
        q_num, question, answer, source, q_type, difficulty = match.groups()
        q_obj = {
            'question': question.strip(),
            'expected_answer': answer.strip()
        }
        if source:
            q_obj['source'] = source.strip()
        if q_type:
            q_obj['type'] = q_type.strip()
        if difficulty:
            q_obj['difficulty'] = difficulty.strip()
        questions.append(q_obj)

    return questions


@test_runner_api.route('/question-sets/upload', methods=['POST'])
@require_auth
def upload_question_set():
    """Upload a question set for a specific vault."""
    import logging
    logger = logging.getLogger(__name__)

    logger.info(f"[Upload] Request files: {list(request.files.keys())}")
    logger.info(f"[Upload] Request form: {dict(request.form)}")

    if 'file' not in request.files:
        logger.error("[Upload] No file in request")
        return jsonify({'error': 'No file provided'}), 400

    vault_id = request.form.get('vault_id')
    if not vault_id:
        logger.error("[Upload] No vault_id in form")
        return jsonify({'error': 'vault_id is required'}), 400

    file = request.files['file']
    logger.info(f"[Upload] Filename: {file.filename}")
    if not file.filename:
        logger.error("[Upload] No filename")
        return jsonify({'error': 'No file selected'}), 400

    if not file.filename.endswith(('.json', '.jsonl', '.md')):
        logger.error(f"[Upload] Invalid extension: {file.filename}")
        return jsonify({'error': 'File must be .json, .jsonl, or .md'}), 400

    name = request.form.get('name') or Path(file.filename).stem
    logger.info(f"[Upload] Name: {name}")

    try:
        content = file.read().decode('utf-8')
        logger.info(f"[Upload] Content length: {len(content)} chars")

        if file.filename.endswith('.md'):
            questions = parse_markdown_questions(content)
            logger.info(f"[Upload] Parsed {len(questions)} questions from markdown")
            if not questions:
                logger.error(f"[Upload] No questions found in markdown. Content preview: {content[:500]}")
                return jsonify({'error': 'No questions found in markdown file. Expected format: ### Q1\\n**Question:** ...\\n**Answer:** ...'}), 400
        elif file.filename.endswith('.jsonl'):
            questions = []
            for line in content.strip().split('\n'):
                if line.strip():
                    questions.append(json.loads(line))
        else:
            data = json.loads(content)
            if isinstance(data, list):
                questions = data
            elif 'questions' in data:
                questions = data['questions']
            else:
                questions = [data]

        question_count = len(questions)

        session = get_db_session()
        try:
            result = session.execute(text("""
                INSERT INTO question_sets (vault_id, name, question_count, questions, uploaded_by)
                VALUES (:vault_id, :name, :count, :questions, :uploaded_by)
                RETURNING id
            """), {
                'vault_id': vault_id,
                'name': name,
                'count': question_count,
                'questions': json.dumps(questions),
                'uploaded_by': 'api'
            })
            question_set_id = result.fetchone()[0]
            session.commit()

            return jsonify({
                'id': str(question_set_id),
                'vault_id': vault_id,
                'name': name,
                'question_count': question_count,
                'message': f'Uploaded {question_count} questions successfully'
            }), 201
        finally:
            session.close()
    except json.JSONDecodeError as e:
        return jsonify({'error': f'Invalid JSON: {str(e)}'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@test_runner_api.route('/question-sets', methods=['GET'])
@require_auth
def list_question_sets():
    """List question sets for a specific vault."""
    vault_id = request.args.get('vault_id')
    if not vault_id:
        return jsonify({'error': 'vault_id query parameter is required'}), 400

    session = get_db_session()
    try:
        result = session.execute(text("""
            SELECT id, name, question_count, uploaded_at, uploaded_by
            FROM question_sets
            WHERE vault_id = :vault_id
            ORDER BY uploaded_at DESC
        """), {'vault_id': vault_id})

        question_sets = []
        for row in result:
            question_sets.append({
                'id': str(row[0]),
                'name': row[1],
                'question_count': row[2],
                'uploaded_at': row[3].isoformat() if row[3] else None,
                'uploaded_by': row[4]
            })

        return jsonify({'question_sets': question_sets})
    finally:
        session.close()


@test_runner_api.route('/question-sets/<uuid:question_set_id>', methods=['GET'])
@require_auth
def get_question_set(question_set_id: UUID):
    """Get a question set with its questions. Requires vault_id query param for ownership validation."""
    vault_id = request.args.get('vault_id')
    if not vault_id:
        return jsonify({'error': 'vault_id query parameter is required'}), 400

    session = get_db_session()
    try:
        result = session.execute(text("""
            SELECT id, name, question_count, questions, uploaded_at, uploaded_by
            FROM question_sets
            WHERE id = :id AND vault_id = :vault_id
        """), {'id': str(question_set_id), 'vault_id': vault_id})

        row = result.fetchone()
        if not row:
            return jsonify({'error': 'Question set not found'}), 404

        return jsonify({
            'id': str(row[0]),
            'name': row[1],
            'question_count': row[2],
            'questions': row[3],
            'uploaded_at': row[4].isoformat() if row[4] else None,
            'uploaded_by': row[5]
        })
    finally:
        session.close()


@test_runner_api.route('/question-sets/<uuid:question_set_id>', methods=['DELETE'])
@require_auth
def delete_question_set(question_set_id: UUID):
    """Delete a question set. Requires vault_id query param for ownership validation."""
    vault_id = request.args.get('vault_id')
    if not vault_id:
        return jsonify({'error': 'vault_id query parameter is required'}), 400

    session = get_db_session()
    try:
        result = session.execute(text("""
            DELETE FROM question_sets WHERE id = :id AND vault_id = :vault_id RETURNING id
        """), {'id': str(question_set_id), 'vault_id': vault_id})

        if not result.fetchone():
            return jsonify({'error': 'Question set not found'}), 404

        session.commit()
        return jsonify({'message': 'Question set deleted successfully'})
    finally:
        session.close()


@test_runner_api.route('/start', methods=['POST'])
@require_auth
def start_test():
    """Start a new test run.

    Request body:
        vault_id: UUID of the vault to test against (required)
        question_set_id: UUID of the question set to use (required)
        mode: 'auto' or 'fresh' (default: 'auto')
            - auto: Use existing vault, run Q&A against it
            - fresh: Delete vault, upload from corpus_folder, extract, then run Q&A
        corpus_folder: Path to corpus folder (required for fresh mode)
        resume_run_id: UUID of a previous run to resume (optional)
    """
    running_test = get_running_test()
    if running_test and running_test.get('status') == 'running':
        return jsonify({
            'error': 'A test is already running',
            'current_test': running_test
        }), 409

    data = request.get_json() or {}
    vault_id = data.get('vault_id')
    question_set_id = data.get('question_set_id')
    mode = data.get('mode', 'auto')
    corpus_folder = data.get('corpus_folder')
    resume_run_id = data.get('resume_run_id')

    if not vault_id:
        return jsonify({'error': 'vault_id is required'}), 400

    if not question_set_id:
        return jsonify({'error': 'question_set_id is required'}), 400

    if mode not in ('auto', 'fresh'):
        return jsonify({'error': 'mode must be "auto" or "fresh"'}), 400

    if mode == 'fresh' and not corpus_folder:
        return jsonify({'error': 'corpus_folder is required for fresh mode'}), 400

    db_session = get_db_session()
    try:
        result = db_session.execute(text("""
            SELECT qs.id, qs.name, t.name as vault_name
            FROM question_sets qs
            LEFT JOIN platform.tenants t ON t.id = qs.vault_id
            WHERE qs.id = :qs_id AND qs.vault_id = :vault_id
        """), {'qs_id': question_set_id, 'vault_id': vault_id})
        row = result.fetchone()
        if not row:
            return jsonify({'error': 'Question set not found or does not belong to this vault'}), 400
        question_set_name = row[1]
        vault_name = row[2] or 'Unknown'
    finally:
        db_session.close()

    if resume_run_id:
        db_session = get_db_session()
        try:
            verify_result = db_session.execute(text("""
                SELECT vault_id, question_set_id, status
                FROM test_runs WHERE id = :id
            """), {'id': resume_run_id})
            row = verify_result.fetchone()
            if not row:
                return jsonify({'error': 'Resume run not found'}), 404
            if str(row[0]) != vault_id or str(row[1]) != question_set_id:
                return jsonify({'error': 'Resume run does not match vault/question set'}), 400
            if row[2] not in ('running', 'interrupted'):
                return jsonify({'error': f'Cannot resume a {row[2]} test. Start a new test instead.'}), 400
        finally:
            db_session.close()

        test_run_id = resume_run_id
        reset_test_run_for_resume(test_run_id)
    else:
        test_run_id = create_test_run(
            vault_id=vault_id,
            vault_name=vault_name,
            question_set_id=question_set_id,
            question_set_name=question_set_name,
            mode=mode,
            corpus_folder=corpus_folder
        )

    cmd = ['python', '-m', 'src.test_runner.runner',
           '--vault-id', vault_id,
           '--question-set-id', question_set_id,
           '--mode', mode,
           '--test-run-id', test_run_id]

    if corpus_folder:
        cmd.extend(['--corpus-folder', corpus_folder])

    initial_stages = {
        'delete': {'status': 'pending' if mode == 'fresh' else 'skipped'},
        'create': {'status': 'pending' if mode == 'fresh' else 'skipped'},
        'upload': {'status': 'pending' if mode == 'fresh' else 'skipped'},
        'extract': {'status': 'pending' if mode == 'fresh' else 'skipped'},
        'qa': {'status': 'pending'}
    }

    initial_status = {
        'status': 'starting',
        'vault_id': vault_id,
        'question_set_id': question_set_id,
        'test_run_id': test_run_id,
        'mode': mode,
        'corpus_folder': corpus_folder,
        'started_at': datetime.now().isoformat(),
        'pid': None,
        'stages': initial_stages,
        'qa_progress': {
            'total': 0,
            'answered': 0,
            'passed': 0,
            'failed': 0,
            'accuracy_percent': 0
        },
        'current_question': None
    }
    write_status_file(initial_status)

    try:
        log_dir = Path('test_results')
        log_dir.mkdir(exist_ok=True)
        log_file = log_dir / f'test_run_{test_run_id}.log'

        with open(log_file, 'w') as log_f:
            log_f.write(f"Starting test run: {test_run_id}\n")
            log_f.write(f"Command: {' '.join(cmd)}\n")
            log_f.write(f"Time: {datetime.now().isoformat()}\n")
            log_f.write("-" * 50 + "\n")

        log_handle = open(log_file, 'a')

        env = os.environ.copy()
        env['PYTHONUNBUFFERED'] = '1'

        process = subprocess.Popen(
            cmd,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            env=env,
            cwd=os.getcwd()
        )

        initial_status['status'] = 'running'
        initial_status['pid'] = process.pid
        write_status_file(initial_status)

        return jsonify({
            'message': 'Test started',
            'pid': process.pid,
            'vault_id': vault_id,
            'test_run_id': test_run_id,
            'mode': mode,
            'command': ' '.join(cmd)
        }), 202
    except Exception as e:
        complete_test_run(test_run_id, status='failed', error_message=str(e))
        initial_status['status'] = 'failed'
        initial_status['error'] = str(e)
        write_status_file(initial_status)
        return jsonify({'error': f'Failed to start test: {str(e)}'}), 500


@test_runner_api.route('/status', methods=['GET'])
@require_auth
def get_test_status():
    """Get current test status.

    Combines status file (for real-time stage updates) with database
    (for persistence and heartbeat-based interrupted detection).
    """
    file_status = read_status_file()
    db_test = get_running_test()

    if db_test:
        if db_test['status'] == 'interrupted':
            if file_status:
                file_status['status'] = 'interrupted'
                file_status['db_status'] = db_test
                write_status_file(file_status)
            return jsonify({
                'status': 'interrupted',
                'test_run_id': db_test['id'],
                'vault_id': db_test['vault_id'],
                'vault_name': db_test['vault_name'],
                'question_set_id': db_test['question_set_id'],
                'question_set_name': db_test['question_set_name'],
                'stage': db_test['stage'],
                'qa_progress': {
                    'total': db_test['questions_total'],
                    'answered': db_test['questions_answered'],
                    'passed': db_test['questions_passed'],
                    'failed': db_test['questions_failed'],
                    'accuracy_percent': round(100 * db_test['questions_passed'] / max(db_test['questions_answered'], 1), 1)
                },
                'checkpoint': db_test['checkpoint'],
                'message': f"Test interrupted at {db_test['questions_answered']}/{db_test['questions_total']} questions. Click Resume to continue."
            })
        elif db_test['status'] == 'running':
            if file_status:
                file_status['test_run_id'] = db_test['id']
                file_status['db_progress'] = {
                    'answered': db_test['questions_answered'],
                    'passed': db_test['questions_passed'],
                    'failed': db_test['questions_failed']
                }
                return jsonify(file_status)
            return jsonify({
                'status': 'running',
                'test_run_id': db_test['id'],
                'vault_id': db_test['vault_id'],
                'vault_name': db_test['vault_name'],
                'stage': db_test['stage'],
                'qa_progress': {
                    'total': db_test['questions_total'],
                    'answered': db_test['questions_answered'],
                    'passed': db_test['questions_passed'],
                    'failed': db_test['questions_failed']
                }
            })

    if not file_status:
        return jsonify({
            'status': 'idle',
            'message': 'No test is currently running'
        })

    if file_status.get('pid'):
        try:
            os.kill(file_status['pid'], 0)
        except OSError:
            qa_stage = file_status.get('stages', {}).get('qa', {})
            qa_progress = file_status.get('qa_progress', {})
            was_in_qa = qa_stage.get('status') == 'running'
            has_progress = qa_progress.get('answered', 0) > 0 and qa_progress.get('answered', 0) < qa_progress.get('total', 0)

            if file_status.get('status') == 'running' or (was_in_qa and has_progress):
                file_status['status'] = 'interrupted'
                file_status['message'] = f"Test interrupted at {qa_progress.get('answered', 0)}/{qa_progress.get('total', 0)} questions. Click Resume to continue."

                if not file_status.get('test_run_id') and file_status.get('vault_id') and file_status.get('question_set_id'):
                    recovered_id = recover_file_test_to_db(file_status)
                    if recovered_id:
                        file_status['test_run_id'] = recovered_id
                        file_status['recovered_from_file'] = True

                write_status_file(file_status)

    return jsonify(file_status)


@test_runner_api.route('/stop', methods=['POST'])
@require_auth
def stop_test():
    """Stop the currently running test."""
    file_status = read_status_file()
    db_test = get_running_test()

    if not file_status and not db_test:
        return jsonify({'error': 'No test is currently running'}), 400

    pid = file_status.get('pid') if file_status else None
    test_run_id = file_status.get('test_run_id') if file_status else (db_test.get('id') if db_test else None)

    try:
        if pid:
            os.killpg(os.getpgid(pid), signal.SIGTERM)

        if test_run_id:
            complete_test_run(test_run_id, status='interrupted', error_message='Manually stopped by user')

        if file_status:
            file_status['status'] = 'stopped'
            file_status['stopped_at'] = datetime.now().isoformat()
            write_status_file(file_status)

        return jsonify({
            'message': 'Test stopped',
            'pid': pid,
            'test_run_id': test_run_id
        })
    except ProcessLookupError:
        if test_run_id:
            complete_test_run(test_run_id, status='interrupted', error_message='Process not found')
        if file_status:
            file_status['status'] = 'finished'
            write_status_file(file_status)
        return jsonify({'message': 'Process already finished'})
    except Exception as e:
        return jsonify({'error': f'Failed to stop test: {str(e)}'}), 500


@test_runner_api.route('/force-clear', methods=['POST'])
@require_auth
def force_clear_tests():
    """Force-clear all tests that are stuck in 'running' status.

    This is a manual override for when tests are stuck and the user
    wants to clear them without waiting for heartbeat timeout.

    Use this when:
    - The dashboard says "A test is already running" but you know nothing is running
    - A test got stuck and you can't start a new one
    """
    try:
        # Kill any process that might still be running
        file_status = read_status_file()
        if file_status and file_status.get('pid'):
            try:
                os.killpg(os.getpgid(file_status['pid']), signal.SIGTERM)
            except (ProcessLookupError, OSError):
                pass  # Process already dead

        # Clear database status
        count = force_clear_all_running_tests()

        # Clear status file
        clear_status_file()

        return jsonify({
            'message': f'Force-cleared {count} stuck test(s)',
            'cleared_count': count
        })
    except Exception as e:
        return jsonify({'error': f'Failed to force-clear tests: {str(e)}'}), 500


@test_runner_api.route('/history', methods=['GET'])
@require_auth
def get_test_history():
    """Get test run history."""
    limit = request.args.get('limit', 50, type=int)
    offset = request.args.get('offset', 0, type=int)

    session = get_db_session()
    try:
        result = session.execute(text("""
            SELECT
                id, vault_id, vault_name, question_set_id, question_set_name,
                mode, corpus_folder, status, stage, started_at, completed_at,
                questions_total, questions_answered, questions_passed, questions_failed,
                error_message, results_file
            FROM test_runs
            ORDER BY started_at DESC
            LIMIT :limit OFFSET :offset
        """), {'limit': limit, 'offset': offset})

        runs = []
        for row in result:
            runs.append({
                'id': str(row[0]),
                'vault_id': str(row[1]) if row[1] else None,
                'vault_name': row[2],
                'question_set_id': str(row[3]) if row[3] else None,
                'question_set_name': row[4],
                'mode': row[5],
                'corpus_folder': row[6],
                'status': row[7],
                'stage': row[8],
                'started_at': row[9].isoformat() if row[9] else None,
                'completed_at': row[10].isoformat() if row[10] else None,
                'questions_total': row[11],
                'questions_answered': row[12],
                'questions_passed': row[13],
                'questions_failed': row[14],
                'error_message': row[15],
                'results_file': row[16]
            })

        count_result = session.execute(text("SELECT COUNT(*) FROM test_runs"))
        total = count_result.fetchone()[0]

        return jsonify({
            'runs': runs,
            'total': total,
            'limit': limit,
            'offset': offset
        })
    finally:
        session.close()


@test_runner_api.route('/results/<uuid:test_id>', methods=['GET'])
@require_auth
def get_test_results(test_id: UUID):
    """Get detailed results for a specific test run."""
    session = get_db_session()
    try:
        run_result = session.execute(text("""
            SELECT
                id, vault_id, vault_name, question_set_id, question_set_name,
                mode, corpus_folder, status, stage, started_at, completed_at,
                questions_total, questions_answered, questions_passed, questions_failed,
                checkpoint, error_message
            FROM test_runs
            WHERE id = :id
        """), {'id': str(test_id)})

        run_row = run_result.fetchone()
        if not run_row:
            return jsonify({'error': 'Test run not found'}), 404

        results_result = session.execute(text("""
            SELECT
                id, question_id, question_text, expected_answer, actual_answer,
                category, passed, failure_reason, duration_ms, answered_at
            FROM test_results
            WHERE test_run_id = :test_id
            ORDER BY answered_at
        """), {'test_id': str(test_id)})

        results = []
        for row in results_result:
            results.append({
                'id': str(row[0]),
                'question_id': row[1],
                'question_text': row[2],
                'expected_answer': row[3],
                'actual_answer': row[4],
                'category': row[5],
                'passed': row[6],
                'failure_reason': row[7],
                'duration_ms': row[8],
                'answered_at': row[9].isoformat() if row[9] else None
            })

        return jsonify({
            'run': {
                'id': str(run_row[0]),
                'vault_id': str(run_row[1]) if run_row[1] else None,
                'vault_name': run_row[2],
                'question_set_id': str(run_row[3]) if run_row[3] else None,
                'question_set_name': run_row[4],
                'mode': run_row[5],
                'corpus_folder': run_row[6],
                'status': run_row[7],
                'stage': run_row[8],
                'started_at': run_row[9].isoformat() if run_row[9] else None,
                'completed_at': run_row[10].isoformat() if run_row[10] else None,
                'questions_total': run_row[11],
                'questions_answered': run_row[12],
                'questions_passed': run_row[13],
                'questions_failed': run_row[14],
                'checkpoint': run_row[15],
                'error_message': run_row[16]
            },
            'results': results
        })
    finally:
        session.close()


@test_runner_api.route('/results-files', methods=['GET'])
@require_auth
def list_results_files():
    """List available results files from the test_results directory."""
    results_dir = Path('test_results').resolve()
    files = []

    if results_dir.exists():
        for item in sorted(results_dir.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
            if item.is_file() and (item.suffix == '.jsonl' or item.suffix == '.json'):
                files.append({
                    'name': item.name,
                    'size': item.stat().st_size,
                    'modified': datetime.fromtimestamp(item.stat().st_mtime).isoformat()
                })

    return jsonify({'results_files': files})


@test_runner_api.route('/results-files/<filename>', methods=['GET'])
@require_auth
def download_results_file(filename: str):
    """Download a results file. Only allows basenames, no path traversal."""
    from flask import send_file
    from urllib.parse import unquote
    import re

    filename = unquote(filename)

    if not filename or not re.match(r'^[\w\-\.]+$', filename):
        return jsonify({'error': 'Invalid filename'}), 400

    if '..' in filename or '/' in filename or '\\' in filename:
        return jsonify({'error': 'Invalid filename'}), 400

    results_dir = Path('test_results').resolve()
    file_path = (results_dir / filename).resolve()

    if not str(file_path).startswith(str(results_dir)):
        return jsonify({'error': 'Invalid filename'}), 400

    if not file_path.exists() or not file_path.is_file():
        return jsonify({'error': 'Results file not found'}), 404

    download = request.args.get('download', 'false').lower() == 'true'

    if download:
        return send_file(file_path, as_attachment=True, download_name=filename)
    else:
        try:
            content = file_path.read_text()
            if file_path.suffix == '.jsonl':
                lines = [json.loads(line) for line in content.strip().split('\n') if line.strip()]
                return jsonify({'filename': filename, 'results': lines, 'count': len(lines)})
            else:
                return jsonify({'filename': filename, 'content': json.loads(content)})
        except Exception as e:
            return jsonify({'error': f'Failed to parse results: {str(e)}'}), 500


@test_runner_api.route('/corpus-folders', methods=['GET'])
@require_auth
def list_corpus_folders():
    """List available corpus folders from test documents directory."""
    folders = []

    if CORPUS_FOLDERS_PATH.exists():
        for item in sorted(CORPUS_FOLDERS_PATH.iterdir()):
            if item.is_dir() and not item.name.startswith('.'):
                doc_count = 0
                doc_folder = item / 'documents'
                if doc_folder.exists():
                    doc_count = sum(1 for f in doc_folder.rglob('*') if f.is_file())

                folders.append({
                    'name': item.name,
                    'path': str(item),
                    'document_count': doc_count
                })

    return jsonify({'corpus_folders': folders})


@test_runner_api.route('/vaults', methods=['GET'])
@require_auth
def list_vaults():
    """List all vaults the user has access to with entity count and last updated."""
    try:
        from uuid import UUID as UUIDType
        from platform_foundation.src.tenant_service import TenantService

        tenant_svc = TenantService()
        vaults = tenant_svc.list_user_vaults(UUIDType(session['user_id']))

        db_session = get_db_session()
        result = []
        try:
            for v in vaults:
                vault_id = str(v['id'])

                entity_count = 0
                try:
                    entity_result = db_session.execute(text("""
                        SELECT COUNT(*) FROM entities WHERE tenant_id = :tenant_id
                    """), {'tenant_id': vault_id})
                    row = entity_result.fetchone()
                    if row:
                        entity_count = row[0]
                except Exception:
                    pass

                result.append({
                    'id': vault_id,
                    'name': v['name'],
                    'entity_count': entity_count,
                    'last_updated': v['updated_at'].isoformat() if v.get('updated_at') else None
                })
        finally:
            db_session.close()

        return jsonify({'vaults': result})
    except Exception as e:
        return jsonify({'error': f'Failed to list vaults: {str(e)}'}), 500
