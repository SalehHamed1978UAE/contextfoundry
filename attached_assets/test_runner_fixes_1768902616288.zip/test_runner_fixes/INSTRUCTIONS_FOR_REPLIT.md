# Test Runner Reliability Fixes

## Overview

These files fix the test runner reliability issues where:
1. Tests get stuck in "running" state after completion
2. "A test is already running" error blocks new tests
3. Server restarts orphan test processes without cleanup

## Files to Replace

Replace these files in `src/test_runner/`:

| File | Description |
|------|-------------|
| `runner.py` | Fixed: Uses try/finally to ALWAYS call `complete_test_run()` |
| `persistence.py` | Fixed: Added `cleanup_orphaned_running_tests()` and `force_clear_all_running_tests()` |
| `api.py` | Fixed: Runs cleanup on startup, added `/force-clear` endpoint |

## Key Changes

### 1. runner.py - Guaranteed Status Update

**Problem:** If any exception occurred during test execution, `complete_test_run()` was never called, leaving the test stuck in "running" status.

**Fix:** Wrapped the entire `run_vault_test()` function in try/finally:

```python
def run_vault_test(...):
    final_status = 'failed'
    error_message = None

    try:
        # ... all test logic ...
        final_status = 'complete'  # Only if we get here
        return results

    except Exception as e:
        error_message = str(e)
        final_status = 'failed'
        return None

    finally:
        # ALWAYS runs, no matter what
        if test_run_id:
            complete_test_run(test_run_id, status=final_status, error_message=error_message)
```

### 2. persistence.py - Startup Cleanup

**Problem:** When the server restarts, orphaned tests stay in "running" status forever (until heartbeat timeout).

**Fix:** Added two new functions:

```python
def cleanup_orphaned_running_tests() -> int:
    """Mark ALL 'running' tests as 'interrupted'.
    Called on server startup."""

def force_clear_all_running_tests() -> int:
    """Manual override to clear stuck tests."""
```

### 3. api.py - Automatic Cleanup + Force Clear Endpoint

**Problem:** No way to recover from stuck tests without manual database edits.

**Fix 1:** Runs cleanup when the module loads (server startup):

```python
def _run_startup_cleanup():
    count = cleanup_orphaned_running_tests()
    if count > 0:
        print(f"[Test Runner API] Startup cleanup: marked {count} orphaned test(s) as interrupted")

_run_startup_cleanup()  # Runs on import
```

**Fix 2:** Added `/api/test-runner/force-clear` endpoint:

```python
@test_runner_api.route('/force-clear', methods=['POST'])
@require_auth
def force_clear_tests():
    """Force-clear all tests that are stuck in 'running' status."""
```

## UI Change Needed

Add a "Force Clear" button to the Test Runner Dashboard that calls:

```javascript
POST /api/test-runner/force-clear
```

This button should be visible when the dashboard shows "A test is already running" but the user knows nothing is actually running.

## Testing the Fix

1. **Replace the files** in `src/test_runner/`
2. **Restart the server** - should see cleanup message in logs if any tests were stuck
3. **Start a test** - should work without "already running" error
4. **Simulate crash** - kill the server mid-test, restart, verify test is marked "interrupted"
5. **Test force-clear** - if anything gets stuck, the force-clear endpoint should fix it

## State Diagram

```
            ┌─────────────────────────────────────────────────────┐
            │                                                     │
            ▼                                                     │
         IDLE ────────► RUNNING ────────► COMPLETE               │
                           │                                      │
                           │ (exception)                          │
                           ├────────────────► FAILED              │
                           │                                      │
                           │ (server restart / heartbeat timeout) │
                           ├────────────────► INTERRUPTED ────────┘
                           │                    │
                           │                    │ (resume)
                           │                    ▼
                           └──────────────── RUNNING
```

**Key guarantee:** Every test that starts WILL end up in COMPLETE, FAILED, or INTERRUPTED. Never stuck in RUNNING.

## Summary

| Issue | Fix |
|-------|-----|
| Test stays "running" after completion | try/finally guarantees `complete_test_run()` is called |
| Server restart orphans tests | Startup cleanup marks all "running" as "interrupted" |
| No manual override | `/force-clear` endpoint clears stuck tests |
| Tests blocked by ghost "running" state | Combination of above fixes ensures this can't happen |
