# Export Package Contents

This ZIP archive contains your strategic analysis and EPM program data in multiple formats.

## Included Files (5):

- report.md
- report.docx
- report-ui.html
- report-ui.docx
- data/strategy.json

## Note: Some Files Skipped

The following files could not be generated in this environment:

- report.pdf (Puppeteer unavailable)
- report-ui.pdf (Puppeteer unavailable)

PDF files require Puppeteer (headless Chrome) which may not be available on mobile devices or certain environments. All other formats (Markdown, Word, HTML, JSON, CSV) are included.


## File Descriptions:

- **report.md** - Full Markdown report with all sections
- **report.docx** - Comprehensive Word document
- **report-ui.html** - HTML report with styled cards and tables
- **report-ui.docx** - Word document with styled layout
- **report.pdf** - PDF version (if available)
- **report-ui.pdf** - Styled PDF version (if available)
- **data/strategy.json** - Strategic analysis data in JSON
- **data/epm.json** - EPM program data (if generated)
- **data/*.csv** - Detailed data exports for assignments, workstreams, resources, risks, and benefits

Generated on: 11/5/2025, 9:51:23 PM
Session ID: session-1762338417527-njvcmq
Version: 1
